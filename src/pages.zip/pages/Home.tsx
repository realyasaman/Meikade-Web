import axios from 'axios';
import React from 'react';
import { useNavigate } from 'react-router-dom';

type poet = {
    id: number,
    name: string,
    description: string,
};

export const Home = () => {
    const navigate = useNavigate();

    const [poetsList, setPoetsList] = React.useState<Array<poet>>([]);

    const [descriptionLine, setDescriptionLine] = React.useState<string>('');

    const fetchCatFact = () => {
      try {
        axios.get("https://api.meikade.com/api/main/poets/simple").then((res) => {
            const list = new Array<poet>();
            for (var i=0; i<res.data.result.length; i++) {
                const p = res.data.result[i];
                const item: poet = {
                    id: p.id,
                    name: p.name,
                    description: p.description,
                };
                list.push(item);
            }
            setPoetsList(list);
        });
      } catch(e) {
        console.debug(e)
      }
    }

    React.useEffect(() => {
        fetchCatFact();
    }, [])
    
    return <div
        style={{
            display: 'flex',
            flexDirection: 'row',
            gap: '8px',
        }}
    >
        <div
            style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '8px',
                alignItems: 'center',
                padding: '20px',
            }}
        >
            <h1>Home</h1>
            {
                poetsList.map((p: poet) => (
                    <div 
                        style={{
                            width: '200px',
                            height: '50px',
                            background: '#f0f0f0',
                            borderRadius: '15px',
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '8px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer',
                        }}
                        onMouseEnter={() => {
                            setDescriptionLine(p.description);
                        }}
                        onClick={() => {
                            navigate('/poet/' + p.id.toString());
                        }}
                    >
                        {p.name}
                    </div>
                ))
            }
        </div>
        <div
            style={{
                padding: '50px',
                textAlign: 'justify',
                direction: 'rtl',
                fontSize: '18px',
                fontFamily: 'Helvetica',
                position: 'static'
            }}
        >
            {descriptionLine}
        </div>
    </div>;
};
