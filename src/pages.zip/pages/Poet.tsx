import axios from 'axios';
import { title } from 'process';
import React from 'react';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom'

type book = { // Change it to book and change all parameters
    title: string,
    subtitle: string,
    id: number|null,
};

export const Poet = () => {
    const navigate = useNavigate();
    const params = useParams();
    const poetId: number = parseInt(params.poet_id!);

    const [booklist, setbooklist] = React.useState<Array<book>>([]);

    const [subtitleLine, setsubtitleLine] = React.useState<string>('');

    const fetchCatFact = () => {
      try {
        const params = {
          params: {
            poet_id: poetId,
            parent_id: 0,
          },
        };
        axios.get("https://api.meikade.com/api/main/categories/simple", params).then((res) => {
            const list = new Array<book>();
            for (var i=0; i<res.data.result.length; i++) {
                const b = res.data.result[i];
                const link: string = b.link; // "page:/poet?id=7&catId=119"
                const idx = link.indexOf('catId=');
                var newId: number|null;
                if (idx >= 0) {
                    newId = parseInt(link.slice(idx+6));
                } else {
                    newId = null;
                }

                const item: book = {
                    title: b.title,
                    subtitle: b.subtitle,
                    id: newId,
                };
                list.push(item);
            }
            
            setbooklist(list);
        });
      } catch(e) {
        console.debug(e)
      }
    }

    React.useEffect(() => {
        fetchCatFact();
    }, [])
    
    return <div
        style={{
            display: 'flex',
            flexDirection: 'row',
            gap: '8px',
        }}
    >
        <div
            style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '8px',
                alignItems: 'center',
                padding: '20px',
            }}
        >
            <h1>{'Poet: ' + poetId.toString()}</h1>
            {
                booklist.map((bk: book) => (
                    <div 
                        style={{
                            width: '200px',
                            height: '50px',
                            background: '#f0f0f0',
                            borderRadius: '15px',
                            display: 'flex',
                            flexDirection: 'column',
                            gap: '8px',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer',
                        }}
                        onMouseEnter={() => {
                            setsubtitleLine(bk.subtitle);
                        }}
                        onClick={() => {
                            navigate('/poet/' + poetId.toString() + '/book/' + bk.id.toString());
                        }}
                    >
                        {bk.title}
                    </div>
                ))
            }
        </div>
        <div
            style={{
                padding: '50px',
                textAlign: 'justify',
                direction: 'rtl',
                fontSize: '18px',
                fontFamily: 'Helvetica',
                position: 'static'
            }}
        >
            {subtitleLine}
        </div>
    </div>;
};
